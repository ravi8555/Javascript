// const url ="data1.json";
import dtjson from './data1.json'
console.log(dtjson)
// myJson();

// function myJson(){
//     fetch(url)
//     .then(rep => rep.json())
//     .then(json => {

//         console.log(json);

//     })
// }
